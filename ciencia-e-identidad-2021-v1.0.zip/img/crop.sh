convert silueta.jpg -crop 600x200+0+0 +repage silueta-CI01.jpg
convert silueta.jpg -crop 600x300+0+200 +repage silueta-CI03.jpg
convert silueta.jpg -crop 600x400+0+500 +repage silueta-CI05.jpg
convert silueta.jpg -crop 600x300+0+900 +repage silueta-CI07.jpg

convert silueta.jpg -crop 600x300+600+0 +repage silueta-CI02.jpg
convert silueta.jpg -crop 600x400+600+300 +repage silueta-CI04.jpg
convert silueta.jpg -crop 600x300+600+700 +repage silueta-CI06.jpg
convert silueta.jpg -crop 600x200+600+1000 +repage silueta-CI08.jpg


convert completa.jpg -crop 600x200+0+0 +repage completa-CI01.jpg
convert completa.jpg -crop 600x300+0+200 +repage completa-CI03.jpg
convert completa.jpg -crop 600x400+0+500 +repage completa-CI05.jpg
convert completa.jpg -crop 600x300+0+900 +repage completa-CI07.jpg

convert completa.jpg -crop 600x300+600+0 +repage completa-CI02.jpg
convert completa.jpg -crop 600x400+600+300 +repage completa-CI04.jpg
convert completa.jpg -crop 600x300+600+700 +repage completa-CI06.jpg
convert completa.jpg -crop 600x200+600+1000 +repage completa-CI08.jpg